public class EmergencyPatient extends Patient{

    // Sub class Constructor
    EmergencyPatient(String name, int age, String birthday) {
        super(name, age, birthday);
    }


    // Override Methods for Patient Type and Priority
    @Override
    public String getPatientType() {
        return "Emergency";
    }

    @Override
    public String getPriority() {
        return "1";
    }
}
