public class Main {
    public static void main(String[] args) {

        // Creating a PatientManagement instance
        PatientManagement Olymp = new PatientManagement();

        // Adding sum patients to the queue
        Patient o1 = new RegularPatient("Dexter", 20, "05/2004");
        Patient o2 = new EmergencyPatient("Quinn", 5, "02/12/2019");
        Patient o3 = new RegularPatient("Angel", 24, "23/12/2023");
        Patient o4 = new EmergencyPatient("Lundy", 40, "18/12/1983");

        // Queue the patients
        Olymp.queuePatient(o1);
        Olymp.queuePatient(o2);
        Olymp.queuePatient(o3);
        Olymp.queuePatient(o4);

        // Print the queue initially
        System.out.println("Initial Patient Queue:");
        Olymp.printPatients();

        // Dequeue patients one by one
        System.out.println("Dequeuing patient:");

        // Dequeue Method test
        Olymp.dequeuePatient();
    }
}
