public class RegularPatient extends Patient {

    // Subclass Constructor
    RegularPatient(String name, int age, String birthday) {
        super(name, age, birthday);
    }


    // Override Methods for Patient Type and Priority
    @Override
    public String getPatientType() {
        return "Regular";
    }

    @Override
    public String getPriority() {
        return "2";
    }
}

