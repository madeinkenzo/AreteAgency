public class PatientManagement {
    private Patient[] patientQueue = new Patient[100];
    private int patientCount = 0;

    public void queuePatient(Patient patient) {

        // Checking if the queue is full
        if (patientCount == patientQueue.length) {
            System.out.println("The queue is full. Cannot add more patients.");
            return;
        }

        // Initialize queueposition to the end of the queue
        int queueposition = patientCount;

        // Find the correct position to insert the new patient
        for (int i = 0; i < patientCount; i++) {
            if (patientQueue[i] != null) {
                if (Integer.parseInt(patient.getPriority()) < Integer.parseInt(patientQueue[i].getPriority())) {
                    queueposition = i;
                    break;
                }
            }
        }

        // Shift elements to the right to make space for the new patient
        for (int i = patientCount; i >  queueposition; i--) {
            patientQueue[i] = patientQueue[i - 1];
        }

        // Insert the new patient at the calculated position
        patientQueue[queueposition] = patient;

        // Increment patientCount
        patientCount++;

        System.out.println("Patient added successfully at queuee " + queueposition);
    }

    // printNextPatient()
    public void printNextPatient() {
        if (patientCount == 0) {
            System.out.println("No patients in queue.");
            return;
        }

        System.out.println("Next patient in line:");
        System.out.println(patientQueue[0].getPatientSummary());
    }

    // printPatients()
    public void printPatients() {
        if (patientCount == 0) {
            System.out.println("No patients in queue.");
            return;
        }

        System.out.println("Patient Queue:");
        for (int i = 0; i < patientCount; i++) {
            System.out.println((i + 1) + ". " + patientQueue[i].getPatientSummary());
        }

        // Optionally, print the next patient
        if (patientCount > 0) {
            System.out.println("Next Patient: " + patientQueue[0].getPatientSummary());
        }
    }

    public Patient dequeuePatient() {
        if (patientCount == 0) {
            System.out.println("No patients in queue.");
            return null;
        }

        // The next patient to be dequeued is at the front of the queue
        Patient nextPatient = patientQueue[0];
        System.out.println("Dequeued: " + nextPatient.getPatientSummary()); // Debugging print

        // Shift all remaining patients to the left
        for (int i = 0; i < patientCount - 1; i++) {
            patientQueue[i] = patientQueue[i + 1];
        }

        // Set the last element to null
        patientQueue[patientCount - 1] = null;

        // Decrease the patient count after removing one
        patientCount--;

        // Print the updated queue
        printPatients();

        return nextPatient;
    }
}
