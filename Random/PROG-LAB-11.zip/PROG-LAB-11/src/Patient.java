public abstract class Patient {
    private String name;
    private int age;
    private String birthday;

    // Superclass Constructor
    Patient(String name, int age, String birthday) {
        this.name = name;
        this.age = age;
        this.birthday = this.birthday;
    }

    // Getter Methods, non abstract and abstract
    public String getName() {
        return name;
    }

    public abstract String getPatientType();

    public abstract String getPriority();

    public String getPatientSummary() {
        return "Name: " + name + ", Type: " + getPatientType() + ", Priority: " + getPriority();
    }

}
