public static void main(String[] args) {
    // Test the method for PasswordUtils
    System.out.println("Your Password: " + PasswordUtils.createRandomPassword(8));

    // Create an address book
    AddressBook addressBook = new AddressBook();

    // Add contacts
    addressBook.addContact(new Contact("John", "Doe", "123-456-7890"));
    addressBook.addContact(new Contact("Jane", "Smith", "987-654-3210"));
    addressBook.addContact(new Contact("Alice","Brown", "555-123-4567"));

    // Attempt to add a duplicate contact
    addressBook.addContact(new Contact("John","Doe", "111-222-3333"));

    // Print all contacts
    System.out.println("All contacts:");
    addressBook.printAllContacts();

    // Search for a contact
    System.out.println("\nSearching for Jane Smith:");
    addressBook.searchContact("Jane", "Smith");

    // Remove a contact
    System.out.println("\nRemoving John Doe:");
    addressBook.removeContact("John", "Doe");


    // Print all contacts after removal
    System.out.println("\nContacts after removal:");
    addressBook.printAllContacts();

    // Sort contacts
    System.out.println("\nSorted contacts:");
    addressBook.sortContacts();
    addressBook.printAllContacts();

    // Clear contacts
    System.out.println("\nClearing all contacts:");
    addressBook.clearContacts();
    addressBook.printAllContacts();


    PuzzleSolver solver = new PuzzleSolver();

// Test grid for horizontal word occurrences
    char[][] grid = {
            {'X', 'M', 'A', 'S', 'X', 'A'},
            {'S', 'A', 'M', 'X', 'A', 'S'},
            {'M', 'X', 'S', 'A', 'M', 'X'},
            {'A', 'S', 'M', 'X', 'A', 'S'},
            {'X', 'M', 'A', 'S', 'X', 'A'},
            {'S', 'A', 'M', 'X', 'A', 'S'}
    };


    String word = "XMAS";
    int count = solver.countHorizontal(grid, word);
    System.out.println("Total horizontal occurrences of " + word + ": " + count);
}



