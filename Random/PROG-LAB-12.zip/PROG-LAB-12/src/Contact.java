public class Contact {
    private String firstName;
    private String lastName;
    private String phoneNumber;

    // Class Constructor
    public Contact(String firstName, String lastName, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
    }

    // Getter and Setter Methods
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // Equals Method to identify duplicates
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Contact) { // Check type in one step
            Contact other = (Contact) obj;
            return firstName.equals(other.firstName) && lastName.equals(other.lastName);
        }
        return false;
    }

    // toString method to print contact information
    @Override
    public String toString() {
        return firstName + " " + lastName + " (" + phoneNumber + ")";
    }
}

