public class PasswordUtils {
    public static String createRandomPassword(int length){
        if (length < 4) {
            throw new IllegalArgumentException("Password length must be at least 4.");
        }

        // Character pools
        String uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowercase = "abcdefghijklmnopqrstuvwxyz";
        String digits = "0123456789";
        String special = "!@#$%^&*";
        String allCharacters = uppercase + lowercase + digits + special;

        StringBuilder password = new StringBuilder();

        // Add one character from each required pool
        password.append(uppercase.charAt((int) (Math.random() * uppercase.length())));
        password.append(lowercase.charAt((int) (Math.random() * lowercase.length())));
        password.append(digits.charAt((int) (Math.random() * digits.length())));
        password.append(special.charAt((int) (Math.random() * special.length())));

        // Fill the rest of the password with random characters
        for (int i = 4; i < length; i++) {
            password.append(allCharacters.charAt((int) (Math.random() * allCharacters.length())));
        }

        return password.toString(); // Convert StringBuilder to String
    }
}

