public class PuzzleSolver {
    public int countHorizontal(char[][] grid, String word) {
        int count = 0;
        int wordLength = word.length();

        // Iterate through each row of the grid
        for (int i = 0; i < grid.length; i++) {
            // Check left to right in the row
            for (int j = 0; j <= grid[i].length - wordLength; j++) {
                // If the substring matches the word from left to right
                if (matches(grid, word, i, j, true)) {
                    count++;
                }
                // If the substring matches the word from right to left
                if (matches(grid, word, i, j, false)) {
                    count++;
                }
            }
        }
        return count;
    }

    //  Method to check if the word matches in a given direction
    private boolean matches(char[][] grid, String word, int row, int col, boolean leftToRight) {
        for (int i = 0; i < word.length(); i++) {
            int currentCol = leftToRight ? col + i : col + word.length() - 1 - i;
            if (grid[row][currentCol] != word.charAt(i)) {
                return false;
            }
        }
        return true;
    }
}