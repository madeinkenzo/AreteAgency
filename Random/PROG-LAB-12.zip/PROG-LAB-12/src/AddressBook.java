import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AddressBook {
    private ArrayList<Contact> contacts;

    // Constructor
    public AddressBook() {
        contacts = new ArrayList<>();
    }

    // Add a new contact
    public void addContact(Contact contact) {
        if (contacts.contains(contact)) { // relies on Contact.equals()
            System.out.println("Contact already exists: " + contact);
        } else {
            contacts.add(contact);
            System.out.println("Contact added: " + contact);
        }
    }

    // Remove a contact based on firstName and lastName
    public void removeContact(String firstName, String lastName) {
        boolean removed = contacts.removeIf(contact ->
                contact.getFirstName().equals(firstName) &&
                        contact.getLastName().equals(lastName)
        );

        if (removed) {
            System.out.println("Contact removed: " + firstName + " " + lastName);
        } else {
            System.out.println("No contact found with name: " + firstName + " " + lastName);
        }
    }

    // Search for a contact
    public void searchContact(String firstName, String lastName) {
        for (Contact contact : contacts) {
            if (contact.getFirstName().equals(firstName) &&
                    contact.getLastName().equals(lastName)) {
                System.out.println("Contact found: " + contact);
                return;
            }
        }
        System.out.println("No contact found with name: " + firstName + " " + lastName);
    }

    // Print all contacts
    public void printAllContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts to display.");
            return;
        }
        System.out.println("All Contacts:");
        for (Contact contact : contacts) {
            System.out.println(contact);
        }
    }

    // Sort contacts alphabetically by lastName, then firstName
    public void sortContacts() {
        Collections.sort(contacts, Comparator
                .comparing(Contact::getLastName)
                .thenComparing(Contact::getFirstName));

        System.out.println("Contacts sorted:");
        printAllContacts();
    }

    // Clear all contacts
    public void clearContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts to clear. Address book is already empty.");
        } else {
            contacts.clear();
            System.out.println("All contacts have been cleared. Address book is now empty.");
        }
    }
}